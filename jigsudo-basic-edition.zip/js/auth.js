/* Authentication Module */
import { auth } from "./firebase-config.js";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
  reauthenticateWithCredential,
  EmailAuthProvider,
  updatePassword,
  deleteUser,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithCredential,
  linkWithPopup,
  reauthenticateWithPopup,
  sendPasswordResetEmail,
  sendEmailVerification,
  verifyBeforeUpdateEmail,
  getAdditionalUserInfo,
} from "https://www.gstatic.com/firebasejs/11.2.0/firebase-auth.js";
import { gameManager } from "./game-manager.js";
import { router } from "./router.js";
import { translations } from "./translations.js";
import { getCurrentLang } from "./i18n.js";
import { toggleModal, showToast } from "./ui.js";
import { checkSeasonMigration } from "./migration.js";

// v1.6.0: Administrative Authorization
export const ADMIN_UIDS = ["SR5GIs3WdpXl6HkmRxhHh4Slg283"];

/**
 * Checks if the current or provided user has administrative privileges.
 * @param {Object} [user] Optional user object to check. Defaults to currentUser.
 * @returns {boolean}
 */
export function isAdmin(user = currentUser) {
  if (!user || user.isAnonymous) return false;
  return ADMIN_UIDS.includes(user.uid);
}

export async function updateUsername(newUsername) {
  const user = auth.currentUser;
  if (!user) return { success: false, error: "No user logged in." };

  try {
    const { checkUsernameAvailability, saveUserStats } =
      await import("./db.js");

    if (user.displayName === newUsername) return { success: true };

    // Always check availability, but pass our own UID to ignore our own record
    const isAvailable = await checkUsernameAvailability(newUsername, user.uid);
    if (!isAvailable) {
      const t = translations[getCurrentLang()] || translations["es"];
      return { success: false, error: t.err_user_exists };
    }

    await updateProfile(user, { displayName: newUsername });
    
    // CRITICAL FIX: Pass the FULL persistent stats, not just the session state!
    const currentStats = gameManager.stats;
    await saveUserStats(user.uid, currentStats, newUsername);

    return { success: true };
  } catch (error) {
    return {
      success: false,
      error: translateAuthError(error.code) || error.message,
    };
  }
}

let currentUser = null;
let isRegistering = false; // Flag to skip clearAllData during registration

export function initAuth() {
  onAuthStateChanged(auth, async (user) => {
    if (user) {
      currentUser = user;
      console.log(
        "User signed in:",
        user.uid,
        user.isAnonymous ? "(Anonymous)" : "(Permanent)",
      );

      if (user.isAnonymous) {
        // GUEST FLOW (Anonymous UID for security/read access)
        gameManager.setUserId(user.uid);
        updateUIForLogout(); // Maintain Guest UI for anonymous sessions

        // Dispatch custom event to signal that auth is ready (even as guest)
        window.dispatchEvent(
          new CustomEvent("authReady", { detail: { user } }),
        );
        return;
      }

      // PERMANENT USER FLOW
      const storedUid = gameManager.getUserId();
      console.log(
        `[Auth] Checking context: storedUid=${storedUid}, firebaseUid=${user.uid}`,
      );

      if (isRegistering) {
        console.log(
          "[Auth] User registration: Preserving guest data for migration.",
        );

        // Send verification email ONLY for email/password users
        // Google users already have verified emails through Google's auth
        const isGoogleUser = user.providerData.some(
          (p) => p.providerId === "google.com",
        );

        if (!isGoogleUser) {
          try {
            auth.languageCode = getCurrentLang();
            await sendEmailVerification(user);
            console.log("[Auth] Verification email sent to:", user.email);
          } catch (e) {
            console.warn("[Auth] Failed to send verification email:", e);
          }
        } else {
          console.log("[Auth] Google user - skipping verification email");
        }

        // Preserve guest state before clear all, so stats are migrated
        gameManager.setUserId(user.uid);
        // v1.4.6/8: Proactive push to anchor guest data before cloud sync can overwrite it
        // MUST BE AWAITED to prevent race condition during initial loadUserProgress
        await gameManager.forceCloudSave();
      } else if (storedUid && storedUid === user.uid) {
        console.log("[Auth] Session resumed: Syncing account...");
        gameManager.isWiping = true; // v1.6.9: LOCK ON during sync phase
      } else {
        console.log(
          `[Auth] Context switch (Mismatch: ${storedUid} -> ${user.uid}): Wiping local data.`,
        );
        gameManager.isWiping = true; // LOCK ON
        await gameManager.clearAllData(false);
        gameManager.setUserId(user.uid);
      }

      // v1.3.6: Season Migration Check on Identity Switch
      await checkSeasonMigration();

      const wasPlaying = !document.body.classList.contains("home-active");
      updateUIForLogin(user);

      // 2. LOAD SYNC
      document.body.classList.add("syncing-account");
      try {
        console.log(`[Auth] Step 2: Syncing account data for ${user.uid}...`);
        const { loadUserProgress, listenToUserProgress, ensureUserProfileExists } =
          await import("./db.js");

        // v1.9.6: Ensure profile exists in DB to prevent permission-denied errors on new/reset accounts
        await ensureUserProfileExists(user.uid, user.displayName);

        // Await the fetch and the handleCloudSync call inside it
        await loadUserProgress(user.uid);

        console.log(
          `[Auth] Sync phase complete. Local state exists:`,
          !!gameManager.getState(),
        );

        gameManager.isWiping = false; // RELEASE LOCK AFTER SYNC
        listenToUserProgress(user.uid); // Start Real-time Conflict Detection

        if (!gameManager.getState()) {
          console.log(
            "[Auth] No compatible cloud progress found. Initializing fresh daily game.",
          );
          await gameManager.prepareDaily();
        }

        // v1.6.0: Robust Game Resumption Check
        // We only resume a stage if we are already at a game route
        // (either #game or a history replay).
        const isAtGame = router.isGameRoute();
        
        if (isAtGame && !gameManager.isReplaying) {
          const state = gameManager.getState();
          const currentStage = state?.progress?.currentStage || "memory";
          console.log(`[Auth] Resuming game session at stage: ${currentStage}`);
          const memoryModule = await import("./memory.js");
          memoryModule.resumeToStage(currentStage);
        }
      } catch (err) {
        console.error("[Auth] Error during sync phase:", err);
        if (!gameManager.getState()) await gameManager.prepareDaily();
      } finally {
        // v1.2.11: Extend wipe lock slightly to ensure sync has fully settled
        setTimeout(() => {
          gameManager.isWiping = false; // LOCK OFF
          console.log("[Auth] Session initialization complete. Lock released.");
          
          // v1.5.2: Proactive Maintenance Check for authenticated users
          const user = auth.currentUser;
          if (user && !user.isAnonymous) {
             gameManager.checkMaintenance();
          }
        }, 500);

        document.body.classList.remove("syncing-account");

        // Dispatch custom event to signal that auth and data are ready
        window.dispatchEvent(
          new CustomEvent("authReady", { detail: { user } }),
        );
      }
    } else {
      currentUser = null;
      console.log("[Auth] No user detected. Standard Guest Mode (Local-only).");

      // Before signal, ensure UI reflects logged-out state (Guest/Anonymous)
      updateUIForLogout();
      gameManager.setUserId(null);

      // Notify app that auth check is complete (even if no user found)
      window.dispatchEvent(
        new CustomEvent("authReady", { detail: { user: null } }),
      );
    }
  });
}

export async function registerUser(email, password, username) {
  isRegistering = true;
  try {
    const { checkUsernameAvailability, saveUserStats } =
      await import("./db.js");
    
    // 1. Check availability BEFORE creating Auth user to prevent duplicates
    const isAvailable = await checkUsernameAvailability(username);
    if (!isAvailable) {
      const t = translations[getCurrentLang()] || translations["es"];
      return { success: false, error: t.err_user_exists };
    }

    const userCredential = await createUserWithEmailAndPassword(
      auth,
      email,
      password,
    );
    const user = userCredential.user;

    await updateProfile(user, { displayName: username });
    updateUIForLogin(user);

    // Show registration success modal IMMEDIATELY
    const regModal = document.getElementById("registration-success-modal");
    if (regModal) {
      console.log(
        "[Auth] Showing registration success modal (Pre-migration)...",
      );
      toggleModal(regModal, true);

      // SMART REDIRECT: Detect email provider
      const emailBtn = document.getElementById("btn-go-to-email");
      const emailText = document.getElementById("go-to-email-text");
      if (emailBtn && emailText) {
        const domain = email.split("@")[1]?.toLowerCase();
        const providers = {
          "gmail.com": { name: "Gmail", url: "https://mail.google.com" },
          "outlook.com": { name: "Outlook", url: "https://outlook.live.com" },
          "hotmail.com": { name: "Hotmail", url: "https://outlook.live.com" },
          "live.com": { name: "Live", url: "https://outlook.live.com" },
          "yahoo.com": { name: "Yahoo", url: "https://mail.yahoo.com" },
          "icloud.com": { name: "iCloud", url: "https://www.icloud.com/mail" },
          "proton.me": { name: "Proton", url: "https://mail.proton.me" },
          "protonmail.com": { name: "Proton", url: "https://mail.proton.me" },
        };

        const found = providers[domain];
        const lang = getCurrentLang();
        if (found) {
          emailBtn.href = found.url;
          emailBtn.classList.remove("hidden");
          emailText.textContent = translations[lang].btn_go_to_email.replace(
            "%%provider%%",
            found.name,
          );
        } else {
          emailBtn.classList.remove("hidden");
          emailBtn.href = `https://${domain}`;
          emailText.textContent = translations[lang].btn_go_to_generic_email;
        }
      }

      const btnClose = document.getElementById("btn-close-reg-success");
      if (btnClose) {
        btnClose.onclick = () => toggleModal(regModal, false);
      }
    }

    await saveUserStats(user.uid, { registeredAt: new Date() }, username);

    const guestStatsStr = localStorage.getItem("jigsudo_user_stats");
    if (guestStatsStr) {
      try {
        const guestStats = JSON.parse(guestStatsStr);
        // v1.5.18: Ensure we don't duplicate points during migration.
        // If they are currently playing, those points will be awarded later via _recalculateNetStats.
        await saveUserStats(user.uid, guestStats, username);
      } catch (e) {
        console.warn("[Auth] Failed to migrate guest stats:", e);
      }
    }

    return { success: true, user };
  } catch (error) {
    console.error("Registration Error:", error.code, error.message);
    return { success: false, error: translateAuthError(error.code) };
  } finally {
    setTimeout(() => {
      isRegistering = false;
    }, 1000);
  }
}

export async function loginUser(email, password) {
  try {
    const userCredential = await signInWithEmailAndPassword(
      auth,
      email,
      password,
    );
    return { success: true, user: userCredential.user };
  } catch (error) {
    console.error("Login Error:", error.code, error.message);
    return { success: false, error: translateAuthError(error.code) };
  }
}

export async function logoutUser() {
  try {
    const { stopListeningAndCleanup } = await import("./db.js");
    stopListeningAndCleanup();

    // 1. Force sync before wiping local data (Ensure points reach the cloud)
    try {
      if (gameManager.isDirty) {
        console.log("[Auth] User is dirty. Forcing final cloud save before logout...");
        await gameManager.forceCloudSave();
      }
    } catch (e) {
      console.warn("[Auth] Final cloud save before logout failed or timed out. Proceeding with logout.", e);
    }

    await gameManager.clearAllData();
    await signOut(auth);
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

export async function loginWithGoogle() {
  const provider = new GoogleAuthProvider();
  const currentUser = auth.currentUser;

  // Pattern: We no longer set isRegistering = true blindy.
  // Instead, the wipe/migrate decision is handled by onAuthStateChanged based on UID mismatch.
  // Exception: registerUser() explicitly sets it for new email/pwd accounts.

  try {
    let result;
    // If we have an anonymous user, try to LINK instead of just signing in.
    // This turns the anonymous account into a permanent Google account (UID stays same).
    if (currentUser && currentUser.isAnonymous) {
      console.log("[Auth] Attempting to link guest account to Google...");
      try {
        result = await linkWithPopup(currentUser, provider);
        console.log("[Auth] Account linked successfully.");
      } catch (linkError) {
        if (linkError.code === "auth/credential-already-in-use") {
          console.log(
            "[Auth] Google account already exists. Signing in directly...",
          );
          // CRUCIAL: Extract the credential from the error and sign in with it.
          // This avoids opening a second popup and solves the 'popup-blocked' issue.
          const credential = GoogleAuthProvider.credentialFromError(linkError);
          result = await signInWithCredential(auth, credential);
        } else {
          throw linkError;
        }
      }
    } else {
      result = await signInWithPopup(auth, provider);
    }

    const user = result.user;
    const { saveUserStats, checkUsernameAvailability } =
      await import("./db.js");

    // Persist username to Firestore if it's a new or migrated account
    // For Google users, we use their Google Display Name or email prefix, ensuring it's UNIQUE
    let assignedName = user.displayName || user.email.split("@")[0];

    // Check if this user (UID) already has a username in our DB to avoid overwriting or redundant checks
    const { doc, getDoc } =
      await import("https://www.gstatic.com/firebasejs/11.2.0/firebase-firestore.js");
    const { db } = await import("./firebase-config.js");
    const userDoc = await getDoc(doc(db, "users", user.uid));
    const existingNameInDb = userDoc.exists() ? userDoc.data().username : null;

    if (!existingNameInDb) {
      // It's a new account or a migration, ensure the assignedName is unique
      let isAvailable = await checkUsernameAvailability(assignedName);
      let counter = 1;
      const baseName = assignedName;

      while (!isAvailable) {
        assignedName = `${baseName}${counter}`;
        isAvailable = await checkUsernameAvailability(assignedName);
        counter++;
      }
    } else {
      // User already exists, keep their current name
      assignedName = existingNameInDb;
    }

    if (currentUser && currentUser.isAnonymous) {
      // Migrating guest stats to permanent Google account
      const guestStatsStr = localStorage.getItem("jigsudo_user_stats");
      if (guestStatsStr) {
        try {
          const guestStats = JSON.parse(guestStatsStr);
          await saveUserStats(user.uid, guestStats, assignedName);
        } catch (e) {
          console.warn("[Auth] Failed to migrate guest stats to Google:", e);
        }
      }
    } else {
      // Regular Google sign-in: OR existing user.
      // Use metadataOnly=true to avoid wiping stats if they exist in the cloud.
      await saveUserStats(user.uid, null, assignedName, true);
    }

    // Explicitly update Firebase profile name if it's missing (helps sync UI immediately)
    if (!user.displayName && assignedName) {
      await updateProfile(user, { displayName: assignedName });
    }

    // Refresh UI manually to ensure assignedName shows up immediately
    updateUIForLogin(user);

    // NEW USER AUTOMATION:
    // If it's a first-time Google sign-in (or linking), open the username modal
    const additionalInfo = getAdditionalUserInfo(result);
    if (additionalInfo && additionalInfo.isNewUser) {
      console.log("[Auth] New Google user detected, prompting for username...");
      setTimeout(() => {
        showPasswordModal("change_username");
      }, 500); // Small delay to let the login UI settle
    }

    return { success: true, user };
  } catch (error) {
    console.error("Google Login Error:", error.code, error.message);
    return { success: false, error: translateAuthError(error.code) };
  } finally {
    // Reset flag after a delay to ensure onAuthStateChanged processed it
    setTimeout(() => {
      isRegistering = false;
    }, 2000);
  }
}

async function reauthenticateUser(user, currentPassword = null) {
  const isGoogleUser =
    user &&
    user.providerData &&
    user.providerData.some((p) => p.providerId === "google.com");

  try {
    if (isGoogleUser) {
      console.log("[Auth] Re-authenticating Google user...");
      const provider = new GoogleAuthProvider();
      await reauthenticateWithPopup(user, provider);
      return { success: true };
    } else {
      if (!currentPassword) {
        throw new Error("Password required for email re-authentication.");
      }
      const credential = EmailAuthProvider.credential(
        user.email,
        currentPassword,
      );
      await reauthenticateWithCredential(user, credential);
      return { success: true };
    }
  } catch (error) {
    console.error(
      "[Auth] Re-authentication failed:",
      error.code,
      error.message,
    );
    return { success: false, error: translateAuthError(error.code) };
  }
}

export async function updateUserPassword(currentPassword, newPassword) {
  const user = auth.currentUser;
  if (!user) return { success: false, error: "No user logged in." };

  const authResult = await reauthenticateUser(user, currentPassword);
  if (!authResult.success) return authResult;

  try {
    await updatePassword(user, newPassword);
    return { success: true };
  } catch (error) {
    return { success: false, error: translateAuthError(error.code) };
  }
}

export async function deleteUserAccount(currentPassword) {
  const user = auth.currentUser;
  if (!user) return { success: false, error: "No user logged in." };

  // CRITICAL: Block all background saves during the deletion process
  gameManager.isWiping = true;

  const authResult = await reauthenticateUser(user, currentPassword);
  if (!authResult.success) {
    gameManager.isWiping = false; // Reset if auth fails
    return authResult;
  }

  try {
    const { wipeUserData } = await import("./db.js");
    const { clearRankingCache } = await import("./ranking.js");
    
    // 1. Delete Firestore Data WHILE we are still authenticated (to have permissions)
    await wipeUserData(user.uid);
    
    // 2. Clear local ranking cache to hide the user immediately
    clearRankingCache();
  } catch (e) {
    console.error("Wipe data failed, proceeding to delete account anyway:", e);
  }

  try {
    // 3. Delete the Auth User
    await deleteUser(user);
    
    // 4. Wipe local game data so the resulting guest session starts clean.
    await gameManager.clearAllData();
    
    // 5. Force sign out cleanup just in case
    await signOut(auth);

    return { success: true };
  } catch (error) {
    gameManager.isWiping = false;
    return { success: false, error: translateAuthError(error.code) };
  }
}

export function getCurrentUser() {
  return currentUser;
}

/**
 * Refreshes the user's data from Firebase.
 * Only reloads if the user is not yet verified to save resources.
 */
export async function refreshUserStatus() {
  const user = auth.currentUser;
  if (user && !user.isAnonymous && !user.emailVerified) {
    console.log("[Auth] Refreshing user status...");
    try {
      await user.reload();
      currentUser = auth.currentUser; // Refresh local reference

      // v1.5.30: If now verified, push to Firestore immediately
      if (currentUser && currentUser.emailVerified) {
        console.log("[Auth] User verified! Pushing status to Firestore...");
        gameManager.forceCloudSave(currentUser.uid);
      }

      return { success: true, user: currentUser };
    } catch (e) {
      console.error("[Auth] Failed to refresh user:", e);
      return { success: false, error: e.message };
    }
  }
  return { success: true, user: currentUser, skipped: true };
}

function updateUIForLogin(user) {
  const authBtn = document.getElementById("btn-auth");
  if (authBtn) authBtn.classList.add("authenticated");

  const loginModal = document.getElementById("login-modal");
  if (loginModal) toggleModal(loginModal, false);

  // Actions visibility is now managed exclusively by profile.js to handle own vs public profiles correctly.

  const loginWrapper = document.getElementById("login-wrapper");
  const loggedInView = document.getElementById("logged-in-view");
  const nameSpan = document.getElementById("user-display-name");

  if (loginWrapper) loginWrapper.classList.add("hidden");
  if (loggedInView) loggedInView.classList.remove("hidden");

  if (nameSpan) {
    const lang = getCurrentLang() || "es";
    const t = translations[lang] || translations["es"];
    const displayName =
      user.displayName ||
      (user.email
        ? user.email.split("@")[0]
        : user.isAnonymous
          ? t.guest || "Anónimo"
          : t.user_default || "Usuario");
    nameSpan.textContent = displayName;

    // Update Avatar Initials in Sidebar and Dropdown
    const initial = displayName.charAt(0).toUpperCase();
    const sidebarAvatar = document.querySelector("#btn-auth .nav-icon");
    const dropdownAvatar = document.querySelector("#btn-view-profile .user-avatar-placeholder");
    if (sidebarAvatar) sidebarAvatar.textContent = initial;
    if (dropdownAvatar) dropdownAvatar.textContent = initial;
  }

  /* Refactored to use Router */
  const isNavigating = router.isNavigating();

  const gameSection = document.getElementById("game-section");
  const isGameActive = gameSection && !gameSection.classList.contains("hidden");

  if (!isNavigating && !isGameActive) {
    if (window.location.hash.startsWith("#profile")) {
      // If we are already on the profile page, just refresh the data to handle the login
      import("./profile.js").then((mod) => {
        if (mod.updateProfileData) mod.updateProfileData();
      });
    } else {
      // If not navigating and not playing, show Home
      router.navigateTo("#");
    }
  }

  const profileEmail = document.getElementById("profile-email-display");
  const profileNameLarge = document.getElementById("profile-name-large");

  if (profileEmail) profileEmail.textContent = user.email;
  if (profileNameLarge) {
    const lang = getCurrentLang() || "es";
    const t = translations[lang] || translations["es"];
    profileNameLarge.textContent =
      user.displayName ||
      (user.isAnonymous ? t.guest || "Anónimo" : t.user_default || "Usuario");
  }

  // SAVE HINTS FOR RANKING FALLBACK
  if (user.uid) localStorage.setItem("jigsudo_active_uid", user.uid);
  if (user.displayName)
    localStorage.setItem("jigsudo_active_username", user.displayName);

  const btnChangeName = document.getElementById("btn-profile-change-name");
  if (btnChangeName)
    btnChangeName.onclick = () => showPasswordModal("change_username");

  const btnChangePass = document.getElementById("btn-profile-change-pw");
  if (btnChangePass)
    btnChangePass.onclick = () => showPasswordModal("change_password");

  const btnDelete = document.getElementById("btn-profile-delete");
  if (btnDelete) btnDelete.onclick = () => showPasswordModal("delete_account");

  const btnChangeEmail = document.getElementById("btn-profile-change-email");
  if (btnChangeEmail)
    btnChangeEmail.onclick = () => showPasswordModal("change_email");

  import("./profile.js").then((module) => {
    module.updateProfileData();
  });

  // v1.5.56: Removed premature forceCloudSave to prevent race conditions on refresh.
  // Rankings will be synced after loadUserProgress completes.

  // Initialize Privacy Toggle
  const privacyToggle = document.getElementById("profile-public-toggle");
  if (privacyToggle) {
    // Optimistic UI: Apply cached local state immediately to avoid visual flicker while DB loads
    const cachedPrivacy = localStorage.getItem(`jigsudo_isPublic_${user.uid}`);
    if (cachedPrivacy !== null) {
      privacyToggle.checked = cachedPrivacy === "true";
    }

    import("./db.js").then(async (dbMod) => {
      const userData = await dbMod.fetchLatestUserData(user.uid);
      if (userData) {
        // Protect against Firestore returning a partial document due to pending merge writes on load
        if (userData.isPublic === undefined && cachedPrivacy !== null) {
          privacyToggle.checked = cachedPrivacy === "true";
        } else {
          privacyToggle.checked = userData.isPublic !== false;
        }
        localStorage.setItem(`jigsudo_isPublic_${user.uid}`, privacyToggle.checked);
      }
      privacyToggle.onchange = (e) => {
        const newVal = e.target.checked;
        dbMod.updateProfilePrivacy(user.uid, newVal);
        localStorage.setItem(`jigsudo_isPublic_${user.uid}`, newVal);
        if (gameManager.stats) {
          gameManager.stats.isPublic = newVal;
          // Trigger a local save to ensure consistency
          gameManager.save();
        }
      };
    });
  }

  const btnLogout = document.getElementById("btn-profile-logout");
  if (btnLogout) {
    btnLogout.onclick = () => {
      const modal = document.getElementById("logout-confirm-modal");
      if (modal) {
        window.history.pushState({ logoutModal: true }, "", window.location.hash);
        toggleModal(modal, true);
      }
    };
  }

  const btnCancelLogout = document.getElementById("btn-cancel-logout-modal");
  const btnConfirmLogout = document.getElementById("btn-confirm-logout-modal");
  const logoutModal = document.getElementById("logout-confirm-modal");

  if (btnCancelLogout && logoutModal) {
    btnCancelLogout.onclick = () => {
      window.history.back();
    };
  }

  if (btnConfirmLogout && logoutModal) {
    btnConfirmLogout.onclick = async () => {
      const { showToast } = await import("./ui.js");
      btnConfirmLogout.textContent = "Saliendo...";
      btnConfirmLogout.disabled = true;
      const result = await logoutUser();
      btnConfirmLogout.textContent = "Cerrar Sesión";
      btnConfirmLogout.disabled = false;
      toggleModal(logoutModal, false);
      if (result.success) showToast("Sesión cerrada correctamente.");
      else showToast("Error al cerrar sesión: " + result.error);
    };
  }
}

function updateUIForLogout() {
  const authBtn = document.getElementById("btn-auth");
  if (authBtn) authBtn.classList.remove("authenticated");

  const loginWrapper = document.getElementById("login-wrapper");
  const loggedInView = document.getElementById("logged-in-view");

  if (loginWrapper) loginWrapper.classList.remove("hidden");
  if (loggedInView) loggedInView.classList.add("hidden");

  // Reset Avatar Initials to placeholder
  const sidebarAvatar = document.querySelector("#btn-auth .nav-icon");
  const guestAvatar = document.querySelector("#btn-guest-profile .user-avatar-placeholder");
  const lang = getCurrentLang() || "es";
  const t = translations[lang] || translations["es"];
  const guestName = t.guest || "Anónimo";
  
  if (sidebarAvatar) sidebarAvatar.textContent = guestName.charAt(0).toUpperCase();
  if (guestAvatar) guestAvatar.textContent = guestName.charAt(0).toUpperCase();

  const profileEmail = document.getElementById("profile-email-display");
  if (profileEmail) profileEmail.textContent = "";

  import("./db.js").then((module) => {
    module.stopListeningAndCleanup();
  });

  // Actions visibility is now managed exclusively by profile.js.

  import("./profile.js").then((module) => {
    module.updateProfileData();
  });

  /* Refactored to use Router */
  const isNavigating = router.isNavigating();
  const gameSection = document.getElementById("game-section");
  const isGameActive = gameSection && !gameSection.classList.contains("hidden");

  if (!isNavigating && !isGameActive) {
    // If not navigating and not playing, ensure we are at Home
    router.navigateTo("#");
  } else if (!isGameActive) {
    // If we ARE navigating but not playing, let the router handle the current hash
    router.handleRoute();
  }

  /* Listener for btn-profile-login-guest handled in main.js to use history-aware openAuthModal */
}

export async function changeUserEmail(currentPassword, newEmail) {
  const user = auth.currentUser;
  if (!user) return { success: false, error: "No user logged in." };

  try {
    const isGoogleUser = user.providerData.some(
      (p) => p.providerId === "google.com",
    );
    if (!isGoogleUser && currentPassword) {
      const credential = EmailAuthProvider.credential(
        user.email,
        currentPassword,
      );
      await reauthenticateWithCredential(user, credential);
    }

    auth.languageCode = getCurrentLang();
    await verifyBeforeUpdateEmail(user, newEmail);
    return { success: true };
  } catch (error) {
    return {
      success: false,
      error: translateAuthError(error.code) || error.message,
    };
  }
}

function translateAuthError(code) {
  const t = translations[getCurrentLang()] || translations["es"];
  switch (code) {
    case "auth/email-already-in-use":
      return t.err_auth_email_in_use;
    case "auth/invalid-email":
      return t.err_auth_invalid_email;
    case "auth/weak-password":
      return t.err_auth_weak_password;
    case "auth/user-not-found":
      return t.err_auth_user_not_found;
    case "auth/wrong-password":
    case "auth/invalid-credential":
      return t.err_auth_wrong_password;
    case "auth/too-many-requests":
      return t.err_auth_too_many_requests;
    case "auth/unauthorized-domain":
      return t.err_auth_unauthorized_domain;
    case "auth/popup-closed-by-user":
      return t.err_auth_popup_closed;
    case "auth/cancelled-popup-request":
      return t.err_auth_cancelled_popup;
    case "auth/popup-blocked":
      return t.err_auth_popup_blocked;
    default:
      return t.err_auth_general + code;
  }
}

export function showPasswordModal(actionType) {
  const modal = document.getElementById("password-confirm-modal");
  const title = document.getElementById("pwd-modal-title");
  const desc = document.getElementById("pwd-modal-desc");
  const newPassContainer = document.getElementById("new-password-container");
  const confirmInput = document.getElementById("confirm-password-input");
  const newPassInput = document.getElementById("new-password-input");
  const verifyPassInput = document.getElementById("verify-password-input");
  const textInput = document.getElementById("modal-text-input");
  const btnConfirm = document.getElementById("btn-confirm-pwd");
  const btnCancel = document.getElementById("btn-cancel-pwd");

  if (!modal) return;

  const emailContainer = document.getElementById("new-email-container");
  if (emailContainer) emailContainer.classList.add("hidden");

  confirmInput.value = "";
  newPassInput.value = "";
  if (verifyPassInput) verifyPassInput.value = "";

  // History Management for Back Button support
  window.history.pushState(
    { profileActionModal: true, action: actionType },
    "",
    window.location.hash,
  );

  toggleModal(modal, true);

  if (!modal.dataset.toggleListenerAttached) {
    modal.addEventListener("click", (e) => {
      const btn = e.target.closest(".toggle-password");
      if (!btn) return;
      e.preventDefault();
      e.stopPropagation();
      const wrapper = btn.closest(".password-wrapper");
      const input = wrapper ? wrapper.querySelector("input") : null;
      if (input) {
        const isPassword = input.type === "password";
        const newType = isPassword ? "text" : "password";
        input.type = newType;
        btn.textContent = isPassword ? "🙈" : "👁️";
        const verifyPassInputRef = document.getElementById(
          "verify-password-input",
        );
        if (input.id === "new-password-input" && verifyPassInputRef) {
          verifyPassInputRef.type = newType;
        }
      }
    });
    modal.dataset.toggleListenerAttached = "true";
  }

  const lang = getCurrentLang() || "es";
  const t = translations[lang] || translations["es"];

  const user = auth.currentUser;
  const isGoogleUser =
    user &&
    user.providerData &&
    user.providerData.some((p) => p.providerId === "google.com");

  if (actionType === "change_username") {
    title.textContent = t.modal_change_name_title;
    desc.textContent = t.modal_change_name_desc;
    newPassContainer.classList.add("hidden");
    if (confirmInput.closest(".password-wrapper")) {
      confirmInput.closest(".password-wrapper").classList.add("hidden");
    } else {
      confirmInput.classList.add("hidden");
    }
    if (textInput) {
      textInput.classList.remove("hidden");
      textInput.placeholder = t.modal_new_name_placeholder;
      const currentName = auth.currentUser.displayName || "";
      // Cleanup if it contains server error message from a failed previous fetch/save
      textInput.value = currentName.includes("Cannot GET") ? "" : currentName;
      textInput.focus();
    }
    const newBtnConfirm = btnConfirm.cloneNode(true);
    btnConfirm.parentNode.replaceChild(newBtnConfirm, btnConfirm);
    newBtnConfirm.textContent = t.btn_confirm;
    newBtnConfirm.onclick = async () => {
      const { showToast } = await import("./ui.js");
      const newName = textInput ? textInput.value.trim() : "";
      if (!newName) {
        showToast(t.toast_name_empty, 3000, "error");
        return;
      }
      newBtnConfirm.disabled = true;
      newBtnConfirm.textContent = t.btn_saving;
      const result = await updateUsername(newName);
      newBtnConfirm.disabled = false;
      newBtnConfirm.textContent = t.btn_confirm;
      if (result.success) {
        showToast(t.toast_name_success, 3000, "success");
        toggleModal(modal, false);
        const nameSpan = document.getElementById("user-display-name");
        if (nameSpan) nameSpan.textContent = newName;
        const profileNameLarge = document.getElementById("profile-name-large");
        if (profileNameLarge) profileNameLarge.textContent = newName;
        try {
          const { updateProfileData } = await import("./profile.js");
          updateProfileData();
        } catch (e) {
          console.error("Error updating profile card:", e);
        }
      } else {
        showToast("Error: " + result.error, 3000, "error");
      }
    };
  } else if (actionType === "change_password") {
    title.textContent = t.modal_change_pw_title;
    desc.textContent = t.modal_change_pw_desc;
    newPassContainer.classList.remove("hidden");
    const currentWrapper = confirmInput.closest(".password-wrapper");
    if (currentWrapper) currentWrapper.classList.remove("hidden");
    else confirmInput.classList.remove("hidden");
    confirmInput.placeholder = t.placeholder_current_pw;
    newPassInput.placeholder = t.placeholder_new_pw;
    if (verifyPassInput) verifyPassInput.placeholder = t.placeholder_verify_pw;
    if (textInput) textInput.classList.add("hidden");
    const newBtnConfirm = btnConfirm.cloneNode(true);
    btnConfirm.parentNode.replaceChild(newBtnConfirm, btnConfirm);
    newBtnConfirm.textContent = t.btn_confirm;
    newBtnConfirm.onclick = async () => {
      const { showToast } = await import("./ui.js");
      const currentPass = confirmInput.value;
      const newPass = newPassInput.value;
      const verifyPass = verifyPassInput ? verifyPassInput.value : "";
      if (!currentPass || !newPass || !verifyPass) {
        showToast(t.toast_pw_empty, 3000, "error");
        return;
      }
      if (newPass !== verifyPass) {
        showToast(t.toast_pw_mismatch, 3000, "error");
        return;
      }
      if (newPass.length < 6) {
        showToast(t.toast_pw_short, 3000, "error");
        return;
      }
      newBtnConfirm.disabled = true;
      newBtnConfirm.textContent = t.btn_processing;
      const result = await updateUserPassword(currentPass, newPass);
      newBtnConfirm.disabled = false;
      newBtnConfirm.textContent = t.btn_confirm;
      if (result.success) {
        showToast(t.toast_pw_success, 3000, "success");
        toggleModal(modal, false);
      } else {
        showToast("Error: " + result.error, 3000, "error");
      }
    };
  } else if (actionType === "delete_account") {
    title.textContent = t.modal_delete_account_title;
    desc.textContent = isGoogleUser
      ? t.modal_delete_account_google_desc
      : t.modal_delete_account_desc;
    title.style.color = "#ff5555";
    newPassContainer.classList.add("hidden");
    const currentWrapper = confirmInput.closest(".password-wrapper");

    if (isGoogleUser) {
      if (currentWrapper) currentWrapper.classList.add("hidden");
      else confirmInput.classList.add("hidden");
    } else {
      if (currentWrapper) currentWrapper.classList.remove("hidden");
      else confirmInput.classList.remove("hidden");
      confirmInput.placeholder = t.placeholder_current_pw;
    }

    if (textInput) textInput.classList.add("hidden");
    const newBtnConfirm = btnConfirm.cloneNode(true);
    btnConfirm.parentNode.replaceChild(newBtnConfirm, btnConfirm);
    newBtnConfirm.textContent = t.btn_confirm;
    newBtnConfirm.onclick = async () => {
      const { showToast } = await import("./ui.js");
      const currentPass = isGoogleUser ? null : confirmInput.value;

      if (!isGoogleUser && !currentPass) {
        showToast(t.toast_pw_enter, 3000, "error");
        return;
      }
      const deleteModal = document.getElementById(
        "delete-account-confirm-modal",
      );
      const btnCancelDelete = document.getElementById(
        "btn-cancel-delete-modal",
      );
      const btnConfirmDelete = document.getElementById(
        "btn-confirm-delete-modal",
      );
      if (deleteModal) {
        window.history.pushState(
          { deleteAccountStep: 2 },
          "",
          window.location.hash,
        );
        toggleModal(deleteModal, true);
        toggleModal(modal, false); // Hide step 1 visually

        if (btnCancelDelete)
          btnCancelDelete.onclick = () => {
            window.history.back();
          };
        if (btnConfirmDelete) {
          btnConfirmDelete.onclick = async () => {
            btnConfirmDelete.disabled = true;
            btnConfirmDelete.textContent = t.btn_deleting;
            const result = await deleteUserAccount(currentPass);
            if (result.success) {
              showToast(t.toast_delete_success, 3000, "success");
              setTimeout(() => window.location.reload(), 2000);
            } else {
              btnConfirmDelete.disabled = false;
              btnConfirmDelete.textContent = t.btn_delete_all;
              showToast("Error: " + result.error, 3000, "error");
              toggleModal(deleteModal, false);
            }
          };
        }
      }
    };
  } else if (actionType === "change_email") {
    title.textContent = t.btn_change_email;
    desc.textContent = t.modal_change_pw_desc; // Use same security warning or similar
    newPassContainer.classList.add("hidden");

    if (textInput) textInput.classList.add("hidden");

    const emailContainer = document.getElementById("new-email-container");
    const emailInput = document.getElementById("new-email-input");
    if (emailContainer) emailContainer.classList.remove("hidden");
    if (emailInput) {
      emailInput.value = "";
      emailInput.focus();
    }

    const currentWrapper = confirmInput.closest(".password-wrapper");
    if (isGoogleUser) {
      if (currentWrapper) currentWrapper.classList.add("hidden");
      else confirmInput.classList.add("hidden");
    } else {
      if (currentWrapper) currentWrapper.classList.remove("hidden");
      else confirmInput.classList.remove("hidden");
      confirmInput.placeholder = t.placeholder_current_pw;
      confirmInput.value = "";
    }

    const newBtnConfirm = btnConfirm.cloneNode(true);
    btnConfirm.parentNode.replaceChild(newBtnConfirm, btnConfirm);
    newBtnConfirm.textContent = t.btn_confirm;
    newBtnConfirm.onclick = async () => {
      const { showToast } = await import("./ui.js");
      const currentPass = isGoogleUser ? null : confirmInput.value;
      const newEmail = emailInput ? emailInput.value.trim() : "";

      if (!isGoogleUser && !currentPass) {
        showToast(t.toast_pw_enter, 3000, "error");
        return;
      }
      if (!newEmail || !newEmail.includes("@")) {
        showToast(t.toast_email_invalid, 3000, "error");
        return;
      }

      newBtnConfirm.disabled = true;
      newBtnConfirm.textContent = t.btn_processing || t.btn_saving;
      const result = await changeUserEmail(currentPass, newEmail);
      newBtnConfirm.disabled = false;
      newBtnConfirm.textContent = t.btn_confirm;

      if (result.success) {
        showToast(t.toast_email_change_sent, 5000, "success");
        toggleModal(modal, false);
      } else {
        showToast("Error: " + result.error, 4000, "error");
      }
    };
  }
  btnCancel.onclick = () => {
    window.history.back();
  };
}

// Global Popstate Handler for Profile Modals (Logout, Delete Account, etc.)
window.addEventListener("popstate", (e) => {
  const pwdModal = document.getElementById("password-confirm-modal");
  const logoutModal = document.getElementById("logout-confirm-modal");
  const deleteConfirmModal = document.getElementById("delete-account-confirm-modal");

  const isPwdOpen = pwdModal && !pwdModal.classList.contains("hidden");
  const isLogoutOpen = logoutModal && !logoutModal.classList.contains("hidden");
  const isDeleteConfirmOpen = deleteConfirmModal && !deleteConfirmModal.classList.contains("hidden");

  // Logical Transitions
  if (e.state && e.state.deleteAccountStep === 2) {
    // We are in Final Warning step
    if (!isDeleteConfirmOpen) toggleModal(deleteConfirmModal, true);
    if (isPwdOpen) toggleModal(pwdModal, false);
  } else if (e.state && (e.state.deleteAccountStep === 1 || e.state.profileActionModal)) {
    // We are in Step 1 (Password/Action Confirmation)
    if (isDeleteConfirmOpen) toggleModal(deleteConfirmModal, false);
    if (!isPwdOpen) toggleModal(pwdModal, true);
  } else if (e.state && e.state.logoutModal) {
    // We are in Logout Confirmation
    if (!isLogoutOpen) toggleModal(logoutModal, true);
  } else {
    // State is null or unrelated -> Close all our modals
    if (isPwdOpen) {
      toggleModal(pwdModal, false);
      const title = document.getElementById("pwd-modal-title");
      if (title) title.style.color = "";
    }
    if (isLogoutOpen) toggleModal(logoutModal, false);
    if (isDeleteConfirmOpen) toggleModal(deleteConfirmModal, false);
  }
});

export async function resendVerification() {
  const user = auth.currentUser;
  if (!user || user.isAnonymous)
    return { success: false, error: "No user logged in." };
  try {
    auth.languageCode = getCurrentLang();
    await sendEmailVerification(user);
    return { success: true };
  } catch (error) {
    return {
      success: false,
      errorCode: error.code,
      error: translateAuthError(error.code) || error.message,
    };
  }
}

export async function sendResetPassword(email) {
  if (!email) return { success: false, error: "Email is required." };
  try {
    auth.languageCode = getCurrentLang();
    await sendPasswordResetEmail(auth, email);
    return { success: true };
  } catch (error) {
    return {
      success: false,
      error: translateAuthError(error.code) || error.message,
    };
  }
}

// Logic to hook up forget password link
export function initForgotPasswordUI() {
  const linkForgot = document.getElementById("link-forgot-password");
  const modalReset = document.getElementById("password-reset-modal");
  const btnCancelReset = document.getElementById("btn-cancel-reset");
  const btnConfirmReset = document.getElementById("btn-confirm-reset");
  const inputResetEmail = document.getElementById("reset-email-input");

  console.log("[Auth] Initializing Forgot Password UI listeners...");

  if (linkForgot && modalReset) {
    linkForgot.addEventListener("click", (e) => {
      e.preventDefault();
      console.log("[Auth] Forgot password link clicked");
      // Hide auth modal if open
      const authModal = document.getElementById("auth-modal");
      if (authModal) toggleModal(authModal, false);

      toggleModal(modalReset, true);
      if (inputResetEmail) {
        // Pre-fill if user typed something in login-email
        const loginEmail = document.getElementById("login-email");
        if (loginEmail && loginEmail.value) {
          inputResetEmail.value = loginEmail.value;
        }
        inputResetEmail.focus();
      }
    });
  } else if (linkForgot || modalReset) {
    // Only warn if there's a Mismatch (one exists but not the other)
    console.warn("[Auth] Forgot password elements partial mismatch:", {
      linkForgot: !!linkForgot,
      modalReset: !!modalReset,
    });
  }

  if (btnCancelReset && modalReset) {
    btnCancelReset.addEventListener("click", () => {
      console.log("[Auth] Cancel reset clicked");
      toggleModal(modalReset, false);
      // Optionally show login modal back
      const authModal = document.getElementById("auth-modal");
      if (authModal) toggleModal(authModal, true);
    });
  }

  if (btnConfirmReset && modalReset && inputResetEmail) {
    btnConfirmReset.addEventListener("click", async () => {
      const email = inputResetEmail.value.trim();
      console.log("[Auth] Confirm reset clicked for:", email);
      if (!email) {
        const { showToast } = await import("./ui.js");
        const lang = getCurrentLang() || "es";
        const t = translations[lang] || translations["es"];
        showToast(t.toast_email_invalid, 3000, "error");
        return;
      }

      btnConfirmReset.disabled = true;
      const originalText = btnConfirmReset.textContent;
      btnConfirmReset.textContent = "...";

      const result = await sendResetPassword(email);

      btnConfirmReset.disabled = false;
      btnConfirmReset.textContent = originalText;

      const { showToast } = await import("./ui.js");
      const lang = getCurrentLang() || "es";
      const t = translations[lang] || translations["es"];

      if (result.success) {
        showToast(t.toast_reset_sent, 4000, "success");
        toggleModal(modalReset, false);
      } else {
        showToast("Error: " + result.error, 4000, "error");
      }
    });
  }
}

// Support both direct execution (module) and DOMContentLoaded
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initForgotPasswordUI);
} else {
  initForgotPasswordUI();
}
