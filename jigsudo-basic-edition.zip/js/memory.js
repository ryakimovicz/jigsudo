import {
  initJigsaw,
  placeInPanel,
  transitionToJigsaw,
  handleSlotClick_v2,
  debugJigsawPlace,
  createPanelPlaceholders,
  fitCollectedPieces, // imported if we want to expose it or use it during resize loop?
  handlePieceSelect,
  checkBoardCompletion,
} from "./jigsaw.js";
import { provideHint as provideSudokuHint } from "./sudoku.js";
import { providePeaksHint } from "./peaks.js";
import { provideSearchHint } from "./search.js";
import { gameManager } from "./game-manager.js";
import { CONFIG } from "./config.js";
import { startTimer } from "./timer.js";
import { translations } from "./translations.js";
import { getCurrentLang, updateTexts } from "./i18n.js";
import { cleanupVictoryUI, updateLevelTitle, updateGameHelp } from "./ui.js";
import { stopVictoryAnimations, debugSolveCode, resumeCodeState } from "./code.js";
import { resumeSudokuState } from "./sudoku.js";
import { resumePeaksState } from "./peaks.js";
import { router } from "./router.js";

// DOM Elements
let memorySection;
let boardContainer;
let cardsContainer;
let collectedLeft;
let collectedRight;

// State
let cards = [];
let flippedCards = [];
let isLocked = false;
let matchesFound = 0;
// let panelCount = 0; // Removed
const TOTAL_PAIRS = 9;

// Timer State (Moved to timer.js)

export function initMemoryGame() {
  console.log("Initializing Memory Game...");

  memorySection = document.getElementById("game-section"); // FIXED ID
  boardContainer = document.getElementById("memory-board");

  // CLEANUP: Reset Board (remove Jigsaw leftovers)
  if (boardContainer) boardContainer.innerHTML = "";

  resetUI();
  if (memorySection) memorySection.classList.add("memory-mode");

  cardsContainer = document.getElementById("memory-cards");
  if (cardsContainer) {
    cardsContainer.classList.remove("cards-hidden");
    cardsContainer.style.opacity = ""; // Force clear any lingering inline opacity
  }
  collectedLeft = document.getElementById("collected-left");
  collectedRight = document.getElementById("collected-right");

  // Start Stage Timer
  gameManager.startStageTimer("memory");

  // Init Jigsaw Logic Reference (Pass Elements)
  // Init Jigsaw Logic Reference (Pass Elements)
  try {
    initJigsaw({
      memorySection,
      boardContainer,
      collectedLeft,
      collectedRight,
    });

    // Info Icon Mobile Interaction
    const infoWrapper = document.querySelector(".info-icon-wrapper");
    const titleContainer = document.querySelector(".header-title-container");
    if (infoWrapper && titleContainer) {
      infoWrapper.addEventListener("click", (e) => {
        e.stopPropagation(); // Prevent closing immediately
        titleContainer.classList.toggle("active");
      });

      // Close when clicking outside
      document.addEventListener("click", () => {
        titleContainer.classList.remove("active");
      });
    }

    // 2. Show Section (and Hide Home)
    if (memorySection) {
      memorySection.classList.remove("hidden");
      document.getElementById("menu-content")?.classList.add("hidden");

      // v3.0.0: Animate Title In
      const t = translations[getCurrentLang()];
      updateLevelTitle(t.game_memory || "Memoria");
      updateGameHelp("memory");
    }

    // 3. Load Data
    const state = gameManager.getState();
    if (!state || !state.data || !state.data.initialPuzzle) {
      throw new Error("No game data found in state!");
    }

    // Reset State
    cards = [];
    flippedCards = [];
    isLocked = false;
    matchesFound = state.memory?.pairsFound || 0;
    cardsContainer.innerHTML = "";
    collectedLeft.innerHTML = "";
    collectedRight.innerHTML = "";

    // Reset Board Slots
    setupBoard(state.data.initialPuzzle);
    createPanelPlaceholders(); // <--- Imported from jigsaw.js

    // 5. Setup Cards
    const puzzleChunks = state.data.chunks || getChunksFromBoard(state.data.initialPuzzle);
    setupCards(puzzleChunks);

    // Initialize Resizing
    fitCollectedPieces(); // Imported

    // Use requestAnimationFrame to ensure the section is visible and measurable
    requestAnimationFrame(() => {
      fitMemoryCards();
      fitCollectedPieces();
    });

    window.addEventListener("resize", () => {
      fitCollectedPieces();
      fitMemoryCards();
    });

    // 6. Resume matches if any
    if (matchesFound > 0) {
      resumeMemoryState();
      
      // v1.9.9: Auto-Advance Protection
      // If the stage is already complete upon hydration, trigger the win sequence
      // to prevent the user from being stuck in a finished level.
      if (matchesFound === TOTAL_PAIRS) {
        console.log("[Memory] Auto-advance triggered: All pairs already found. Transitioning in 500ms...");
        setTimeout(() => {
            handleMatchSuccess(null); // Trigger transition
        }, 500);
      }
    }
  } catch (err) {
    console.error("[Memory] Initialization Failed:", err);
    alert("Error iniciando juego: " + err.message);
    // Try to recover home
    if (memorySection) memorySection.classList.add("hidden");
    document.getElementById("menu-content")?.classList.remove("hidden");
  }

  // Start Timer
  initTimer();

  // Debug Button matching
  attachDebugListener();
}

/**
 * Attaches the Magic Wand (Debug Tool) event listener.
 */
export function attachDebugListener() {
  const debugBtn = document.getElementById("debug-help-btn");
  if (debugBtn) {
    debugBtn.onclick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      console.log("Debug button clicked");
      // v1.3.3: Artificial delay to prevent anti-cheat "too fast" errors on server
      setTimeout(() => {
        debugAutoMatch();
      }, 150);
    };
  }
}

/**
 * Routes the application to a specific stage during resumption.
 */
export async function resumeToStage(stage) {
  console.log(`[Memory] Resuming to stage: ${stage}`);

  if (stage === "memory") {
    initMemoryGame();
    return;
  }

  resetUI();

  // 1. Initialize logic references (Jigsaw, Timer, etc.)
  memorySection = document.getElementById("game-section");
  boardContainer = document.getElementById("memory-board");
  cardsContainer = document.getElementById("memory-cards");
  collectedLeft = document.getElementById("collected-left");
  collectedRight = document.getElementById("collected-right");

  initJigsaw({
    memorySection,
    boardContainer,
    collectedLeft,
    collectedRight,
  });

  // 2. Hide Home & Show Game
  if (memorySection) memorySection.classList.remove("hidden");
  document.getElementById("menu-content")?.classList.add("hidden");

  // Hide Footer during Gameplay
  const footer = document.querySelector(".main-footer");
  if (footer && router.isGameRoute()) footer.classList.add("hidden");

  // 3. Setup Board (Empty slots for Jigsaw/Sudoku/etc)
  const state = gameManager.getState();
  if (state.data?.initialPuzzle) {
    setupBoard(state.data.initialPuzzle);
    createPanelPlaceholders();
  }

  // 4. Hydrate Previous Stages
  // Even if we are in Sudoku, we need Jigsaw pieces in slots / Memory pieces in panel
  resumeMemoryState();

  if (stage === "jigsaw") {
    const m = await import("./jigsaw.js");
    m.resumeJigsawState();
    m.transitionToJigsaw();
  } else if (stage === "sudoku") {
    const jigsaw = await import("./jigsaw.js");
    jigsaw.resumeJigsawState();
    const sudoku = await import("./sudoku.js");
    sudoku.resumeSudokuState();
    sudoku.transitionToSudoku();
  } else if (stage === "peaks") {
    const jigsaw = await import("./jigsaw.js");
    jigsaw.resumeJigsawState();
    const peaks = await import("./peaks.js");
    peaks.transitionToPeaks();
  } else if (stage === "search") {
    const jigsaw = await import("./jigsaw.js");
    jigsaw.resumeJigsawState();
    const search = await import("./search.js");
    search.transitionToSearch();
  } else if (stage === "code") {
    const jigsaw = await import("./jigsaw.js");
    jigsaw.resumeJigsawState();
    const search = await import("./search.js");
    search.transitionToCode();
  }

  // 5. Start Global Timer
  initTimer();

  // 6. Attach Debug Tool Listener
  attachDebugListener();
}

/**
 * Global cleanup to prevent UI leakage between stages.
 */
export function resetUI() {
  console.log("[UI] Resetting stage UI...");

  // 0. Cleanup Victory UI (Flying digits, summary modal, etc)
  cleanupVictoryUI();
  stopVictoryAnimations();

  const stageClasses = [
    "memory-mode",
    "jigsaw-mode",
    "sudoku-mode",
    "peaks-mode",
    "search-mode",
    "code-mode",
  ];

  // 1. Clear Classes
  document.body.classList.remove(...stageClasses);
  const gameSection = document.getElementById("game-section");
  if (gameSection) gameSection.classList.remove(...stageClasses);

  // 2. Hide Specific Controls
  const sudokuControls = document.getElementById("sudoku-controls");
  const peaksStats = document.getElementById("peaks-stats");
  const searchTargets = document.getElementById("search-targets-container");

  if (sudokuControls) sudokuControls.classList.add("hidden");
  if (peaksStats) peaksStats.classList.add("hidden");
  if (searchTargets) searchTargets.remove();

  // Hide Footer aggressively in any game stage
  const footer = document.querySelector(".main-footer");
  if (footer && router.isGameRoute()) footer.classList.add("hidden");

  // 1.5 AGGRESSIVE BOARD CLEANUP (Ghosting Fix)
  const board = document.getElementById("memory-board");
  if (board) {
    // Clear all stage-specific cell markers
    const allCells = board.querySelectorAll(".mini-cell");
    allCells.forEach((cell) => {
      cell.classList.remove(
        "peaks-found",
        "peak-found",
        "valley-found",
        "correct-search-path",
        "search-selecting",
        "search-selected",
        "search-found-cell",
        "code-cell",
        "code-active",
        "code-error",
        "code-correct",
      );
      cell.title = ""; // Clear tooltips
    });
  }

  // 3. Reset Header/Tooltip state
  const titleContainer = document.querySelector(".header-title-container");
  if (titleContainer) titleContainer.classList.remove("active");

  // 4. Localized Texts (Sync title with current stage)
  updateTexts();
}

/**
 * Hydrates pieces into the panel/board based on past Memory matches.
 */
export function resumeMemoryState() {
  const state = gameManager.getState();
  if (!state) return;

  // 1. Normalize and Deduplicate indices (ensure they are strings)
  // v1.9.9: Robust Data Validation
  // Filter out any NaN or corrupt values from matchedIndices to prevent downstream crashes
  const matchedIndices = (state.memory?.matchedIndices || [])
    .map(idx => parseInt(idx))
    .filter(idx => !isNaN(idx));

  console.log(`[Memory] Hydrating ${matchedIndices.length} matched pieces.`);
  matchesFound = matchedIndices.length;

  matchedIndices.forEach((idx) => {
    // Re-place the pieces
    if (parseInt(idx) === 4) {
      placeInBoard(idx);
    } else {
      placeInPanel(idx);
    }

    // Flip/Mark the cards
    const cardElements = document.querySelectorAll(
      `.memory-card[data-chunk-index="${idx}"]`,
    );
    cardElements.forEach((card) => {
      card.classList.add("flipped", "matched");
      card.style.pointerEvents = "none";
    });
  });

  // Check if we should even show cards
  // v1.9.7: Resilience Guard - Support both legacy and modern state
  const currentStage = state?.progress?.currentStage || state?.currentStage || "memory";
  if (currentStage !== "memory") {
    if (cardsContainer) cardsContainer.classList.add("cards-hidden");
  } else {
    if (cardsContainer) cardsContainer.classList.remove("cards-hidden");
  }
}

function debugAutoMatch() {
  if (window.isGameTransitioning) {
    console.log("Debug blocked: Transition in progress.");
    return;
  }
  const gameSection = document.getElementById("game-section"); // FIXED ID
  if (!gameSection) return;

  if (gameSection.classList.contains("jigsaw-mode")) {
    debugJigsawPlace();
    return;
  }

  if (gameSection.classList.contains("sudoku-mode")) {
    provideSudokuHint();
    return;
  }

  if (gameSection.classList.contains("peaks-mode")) {
    providePeaksHint();
    return;
  }

  if (gameSection.classList.contains("search-mode")) {
    provideSearchHint();
    return;
  }

  if (gameSection.classList.contains("code-mode")) {
    debugSolveCode();
    return;
  }

  // 1. Find unmatched chunks (Memory Logic)
  const availableCards = Array.from(
    document.querySelectorAll(".memory-card:not(.matched)"),
  );
  if (availableCards.length === 0) return;

  // 2. Group by chunkIndex
  const pairs = {};
  availableCards.forEach((card) => {
    const idx = card.dataset.chunkIndex;
    if (!pairs[idx]) pairs[idx] = [];
    pairs[idx].push(card);
  });

  // 3. Pick random pair
  const indices = Object.keys(pairs);
  if (indices.length === 0) return;
  const randomIdx = indices[Math.floor(Math.random() * indices.length)];
  const pairToMatch = pairs[randomIdx];

  // 4. Force Match Directly (Bypass Game Loop to prevent spam race conditions)
  if (pairToMatch && pairToMatch.length === 2) {
    const [c1, c2] = pairToMatch;

    // IMMEDIATE LOCK: Mark as matched visually to prevent re-selection
    c1.classList.add("matched");
    c2.classList.add("matched");
    c1.classList.add("flipped");
    c2.classList.add("flipped");
    c1.classList.add("match-anim");
    c2.classList.add("match-anim");

    // Clear global flipped if we stole them
    if (flippedCards.includes(c1) || flippedCards.includes(c2)) {
      flippedCards = [];
    }

    // A. Spawn Piece FAST (100ms)
    setTimeout(() => {
      handleMatchSuccess(randomIdx);
    }, 100);

    // B. Finalize Card State (300ms)
    setTimeout(() => {
      disableCards([c1, c2]);
    }, 300);
  }
}

// Mobile/Tablet Responsive Sizing for Memory Cards
function fitMemoryCards() {
  const cardsContainer = document.getElementById("memory-cards");
  if (!cardsContainer) return;

  // We now rely strictly on pure CSS (memory.css) utilizing clamp() and explicitly calculated dvh budgets
  // This JS function only cleans up inline styles that might have been accidentally left over from past logic.

  cardsContainer.style = "";
  
  const cardElements = document.querySelectorAll(".memory-card");
  cardElements.forEach((card) => {
    card.style.width = "";
    card.style.height = "";
    card.style.margin = "";
    card.style.flexShrink = ""; 
  });
}

export function getChunksFromBoard(board) {
  const chunks = [];
  for (let tr = 0; tr < 3; tr++) {
    for (let tc = 0; tc < 3; tc++) {
      const chunk = [];
      for (let r = 0; r < 3; r++) {
        const row = [];
        for (let c = 0; c < 3; c++) {
          row.push(board[tr * 3 + r][tc * 3 + c]);
        }
        chunk.push(row);
      }
      chunks.push(chunk);
    }
  }
  return chunks;
}

function setupBoard() {
  boardContainer.innerHTML = "";
  // Create 9 placeholder slots for the chunks to land in.
  for (let i = 0; i < 9; i++) {
    const slot = document.createElement("div");
    slot.classList.add("sudoku-chunk-slot");
    slot.dataset.slotIndex = i;
    // Add Jigsaw Slot Listener
    slot.addEventListener("click", () => handleSlotClick_v2(i));
    boardContainer.appendChild(slot);
  }
}

function setupCards(chunks) {
  // Generate 18 cards (9 pairs)
  const deck = [];

  chunks.forEach((chunk, index) => {
    // Pair 1
    deck.push({ id: `pair-${index}-a`, chunkIndex: index, chunkData: chunk });
    // Pair 2
    deck.push({ id: `pair-${index}-b`, chunkIndex: index, chunkData: chunk });
  });

  // Render (Ordered Pairs)
  deck.forEach((cardData) => {
    const cardEl = createCardElement(cardData);
    cardsContainer.appendChild(cardEl);
    cards.push(cardEl);
  });

  // Force Layout Update
  fitMemoryCards();

  // Preview Phase
  previewCards();
}

function previewCards() {
  isLocked = true;
  // Staggered Flip UP
  cards.forEach((card, i) => {
    if (card.classList.contains("matched")) return;
    setTimeout(() => {
      card.classList.add("flipped");
    }, i * 30); // Fast ripple (30ms per card)
  });

  setTimeout(() => {
    // Staggered Flip DOWN
    cards.forEach((card, i) => {
      if (card.classList.contains("matched")) return;
      setTimeout(() => {
        card.classList.remove("flipped");
      }, i * 30);
    });

    // Start Visual Shuffle after last unflip finishes
    setTimeout(
      () => {
        visualShuffle();
      },
      500 + cards.length * 30,
    ); // Wait for sequence + buffer
  }, 3000); // 3 Seconds Preview
}

function visualShuffle() {
  // 1. Record Initial Positions (First)
  const firstRects = new Map();
  cards.forEach((card) => {
    if (card.classList.contains("matched")) return;
    firstRects.set(card, card.getBoundingClientRect());
  });

  // 2. Shuffle DOM Order (Last)
  // We can just shuffle the 'cards' array and re-append
  shuffleArray(cards);
  cards.forEach((card) => cardsContainer.appendChild(card));

  // Force layout update (fit cards might need re-run if layout engine is weird, but usually flex just reflows)
  // fitMemoryCards(); // Ensure sizing is still correct

  // 3. Invert (Calculate delta)
  cards.forEach((card) => {
    if (card.classList.contains("matched")) return;
    const first = firstRects.get(card);
    const last = card.getBoundingClientRect();
    const deltaX = first.left - last.left;
    const deltaY = first.top - last.top;

    // Apply Transform to put card back at start position
    card.style.transition = "none";
    card.style.transform = `translate(${deltaX}px, ${deltaY}px)`;
  });

  // 4. Play (Animate to new position) with STAGGER
  // Shuffle phase: Randomize delay for each card to create chaotic feel
  const baseDelay = 50;

  cards.forEach((card, index) => {
    if (card.classList.contains("matched")) return;
    // Random delay between 0 and 300ms
    const randomDelay = Math.random() * 300;

    setTimeout(() => {
      requestAnimationFrame(() => {
        // Enable transition
        card.style.transition =
          "transform 0.6s cubic-bezier(0.25, 0.8, 0.25, 1)";
        // Clear transform to move to natural shuffled position
        card.style.transform = "";
      });
    }, baseDelay + randomDelay);
  });

  // Unlock after animation
  setTimeout(() => {
    isLocked = false;
    // Clean up inline styles
    cards.forEach((card) => {
      card.style.transition = "";
      card.style.transform = "";
    });
  }, 600 + 350); // Max delay ~350
}

// Helper to render mini grid
// Helper to render mini grid
export function createMiniGrid(chunkData, chunkIndex = null) {
  const table = document.createElement("div");
  table.classList.add("mini-sudoku-grid");
  if (chunkIndex !== null) {
    table.dataset.chunkIndex = chunkIndex;
  }

  // If chunkData has 'chunkData' property (nested object issue ref line 301)
  // Ensure we are iterating the 2D array
  const gridData = Array.isArray(chunkData[0])
    ? chunkData
    : chunkData.chunkData;

  if (gridData) {
    gridData.forEach((row) => {
      row.forEach((num) => {
        const cell = document.createElement("div");
        cell.classList.add("mini-cell");
        cell.textContent = num !== 0 ? num : "";
        if (num !== 0) cell.classList.add("has-number");
        table.appendChild(cell);
      });
    });
  }
  return table;
}

function createCardElement(data) {
  const card = document.createElement("div");
  card.classList.add("memory-card");
  card.dataset.chunkIndex = data.chunkIndex;

  const inner = document.createElement("div");
  inner.classList.add("memory-card-inner");

  const front = document.createElement("div");
  front.classList.add("memory-card-front");
  front.textContent = "?";

  const back = document.createElement("div");
  back.classList.add("memory-card-back");

  back.appendChild(createMiniGrid(data.chunkData, data.chunkIndex));

  inner.appendChild(front);
  inner.appendChild(back);
  card.appendChild(inner);

  card.addEventListener("click", () => handleCardClick(card));

  return card;
}

function handleCardClick(card) {
  if (isLocked) return;
  if (card === flippedCards[0]) return; // Clicked same card
  if (card.classList.contains("flipped")) return; // Already matched/flipped

  flipCard(card);
  flippedCards.push(card);

  if (flippedCards.length === 2) {
    checkForMatch();
  }
}

function flipCard(card) {
  card.classList.add("flipped");
}

function unflipCards() {
  isLocked = true;
  setTimeout(() => {
    flippedCards.forEach((card) => card.classList.remove("flipped"));
    // 4. Update Stats
    updateStats();
    flippedCards = [];
    isLocked = false;
  }, 600);
}

function updateStats() {
  // Placeholder for stats update
}

function checkForMatch() {
  const [card1, card2] = flippedCards;
  const idx1 = card1.dataset.chunkIndex;
  const idx2 = card2.dataset.chunkIndex;

  if (idx1 === idx2) {
    // 1. Success Animation (Green Border)
    // Non-blocking: Clear global immediately so user can keep playing
    flippedCards = [];

    card1.classList.add("match-anim");
    card2.classList.add("match-anim");

    // 2. Wait for animation, then process match
    // A. Spawn Piece FAST (100ms) per user request
    setTimeout(() => {
      handleMatchSuccess(idx1);
    }, 100);

    // B. Finalize Card State (300ms) to match animation duration
    setTimeout(() => {
      disableCards([card1, card2]);
    }, 450);
  } else {
    unflipCards();
  }
}

function disableCards(cardsToDisable) {
  const target = cardsToDisable || flippedCards;
  target.forEach((card) => {
    card.style.pointerEvents = "none";
    // Remove the temporary green pulse so it settles to the neutral 'matched' state
    card.classList.remove("match-anim");
    // Optional: fade them out or keep them until we place the prize?
    // We will keep them for a moment then maybe remove them if we want to simulate "moving"
    // But for now we just spawn the prize and leave cards (or hide them).
    // Instead of hiding, we mark them as matched/disabled visually
    // card.style.visibility = "hidden"; // Removed per user request
    card.classList.add("matched");
  });
  if (!cardsToDisable) flippedCards = [];
}

export function handleMatchSuccess(e) {
  // v1.9.9b: Support for manual/auto-advance triggers
  if (e && typeof e.stopPropagation === 'function') e.stopPropagation();
  
  const chunkIndex = (e !== null) 
    ? (typeof e === 'object' ? e.target?.dataset?.chunkIndex : e)
    : null;

  // If e is null, we are triggering a check for already-completed stage
  if (e !== null) {
    if (chunkIndex === null || chunkIndex === undefined) return;

    matchesFound++;

    // SYNC STATE: Save matches count and indices
    const state = gameManager.getState();
    if (!state.memory.matchedIndices) state.memory.matchedIndices = [];

    const idStr = String(chunkIndex);
    if (!state.memory.matchedIndices.map(String).includes(idStr)) {
      state.memory.matchedIndices.push(idStr);
    }

    gameManager.updateProgress("memory", {
      pairsFound: [...new Set(state.memory.matchedIndices)].length,
      matchedIndices: state.memory.matchedIndices,
    });
  }
  
  // v1.3.2: Only save if we haven't won yet. If we won, awardStagePoints will handle the final save.
  const TOTAL_PAIRS = 9;
  if (matchesFound < TOTAL_PAIRS) {
    gameManager.save();
  }

  console.log(`Matched Pair for Chunk ${chunkIndex}!`);

  const idx = parseInt(chunkIndex);
  if (idx === 4) {
    placeInBoard(idx);
  } else {
    placeInPanel(idx);
  }

  // Check Win
  if (matchesFound === TOTAL_PAIRS) {
    // 500ms delay removed per user request for immediate feedback
    // 1. Hide Cards
    if (cardsContainer) cardsContainer.classList.add("cards-hidden");

    // 2. Pulse Board
    if (boardContainer) boardContainer.classList.add("board-complete");

    // 3. Transition to Jigsaw (Keep Timer Running!)
    setTimeout(async () => {
      if (boardContainer) boardContainer.classList.remove("board-complete");

      // Timer Transition
      gameManager.stopStageTimer();
      // v2.1.0: Atomic Advance - Advance stage (which awards points and forces cloud save)
      await gameManager.advanceStage(); 
      gameManager.startStageTimer("jigsaw");

      transitionToJigsaw();
    }, 700); // Wait for pulse/fade (0.6s) + buffer
  }
}

function placeInBoard(chunkIndex) {
  const slot = boardContainer.querySelector(
    `[data-slot-index="${chunkIndex}"]`,
  );
  if (slot) {
    slot.innerHTML = "";
    slot.classList.add("filled");

    const state = gameManager.getState();
    const chunkData = state.data.chunks[chunkIndex];
    if (!chunkData) {
      console.error(`[Memory] No chunk data for index ${chunkIndex}`);
      return;
    }

    const content = createMiniGrid(chunkData, chunkIndex);
    // Maybe ensure it fills the slot perfectly?
    content.style.width = "100%";
    content.style.height = "100%";

    slot.appendChild(content);
  }
}

// Mobile Responsive Sizing Logic (Moved to Module Scope)

// Global Resize Listener with Debounce
let resizeTimeout;
window.addEventListener("resize", () => {
  clearTimeout(resizeTimeout);
  resizeTimeout = setTimeout(() => {
    // Re-run sizing logic when window changes
    fitMemoryCards();
    fitCollectedPieces();
  }, 100);
});

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

// Timer Functions (Delegated to timer.js)
function initTimer() {
  startTimer(() => {
    // Force layout update in case viewport settled
    setTimeout(() => {
      fitMemoryCards();
      fitCollectedPieces();
    }, 500);
  });
}
